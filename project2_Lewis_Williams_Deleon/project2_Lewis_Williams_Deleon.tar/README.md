# JOGOS

# Group Members
 - Orlando Lewis
 - Gabriel Deleon
 - Justin Williams

## Contents of .tar
 - README
 - Part 1:
  - empty.c
  - part1.c
  - empty.trace
  - part1.trace
 - Part 2:
  - my_timer.c
  - Makefile
      - compile using "make"
 - Part 3:
  - elevator.c
  - Makefile
      - compile using "sudo make"

## Bugs
 - No bugs that we know of exist.

## Division of Labor
 - Part 1: We all worked on Part 1 separately
 - Part 2: We all worked on Part 2 separately
 - Part 3: We all worked on Part 3 together
